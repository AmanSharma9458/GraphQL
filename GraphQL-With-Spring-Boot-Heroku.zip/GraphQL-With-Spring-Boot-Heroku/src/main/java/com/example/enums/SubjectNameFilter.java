package com.example.enums;

public enum SubjectNameFilter {

	All,
	Java,
	MySQL,
	MongoDB
}
